# 3D Animation

Make a narrated 3D animated myth-busting short with Claude Code.

1. Open this folder in Claude Code.
2. Say **"let's make a video."**
3. Follow the guided steps — Claude writes everything, you run the prompts
   in your own generator, Claude voices and cuts the final video.

New here? Read **EXPLAINER.md** — one page, tells you everything.
